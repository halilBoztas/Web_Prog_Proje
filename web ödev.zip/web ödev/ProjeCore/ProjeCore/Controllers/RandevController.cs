﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjeCore.Models;

namespace ProjeCore.Controllers
{
    public class RandevController : Controller
    {
        Context c = new Context();
        public IActionResult Index()
        {
            var deger = c.Personels.Include(x => x.Birim).ToList();
            return View(deger);
        }
        [HttpGet]
        public IActionResult Al()
        {
            // Birimler listesini çekiyoruz
            ViewBag.Birimler = c.Birims.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Al(Randev randevu)
           
        {
            var randevuVar = c.Randevs.Any(x => x.PersonelID == randevu.PersonelID && x.Tarih.Date == randevu.Tarih.Date && x.Saat == randevu.Saat && x.KullaniciID==randevu.KullaniciID  );

            if (randevuVar)
            {
                TempData["ErrorMessage"] = "Bu tarih ve saatte randevu alınmıştır.";
                return RedirectToAction("Al");
            }


            c.Randevs.Add(randevu);
            c.SaveChanges();

            TempData["SuccessMessage"] = "Randevunuz başarıyla alındı.";
            return RedirectToAction("Index", "Kullanici");
        }
    }
}
