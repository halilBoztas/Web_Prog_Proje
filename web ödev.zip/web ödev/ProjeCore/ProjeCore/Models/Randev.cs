﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjeCore.Models
{
    public class Randev
    {

        [Key]
        public int RandevuID { get; set; }

        public int KullaniciID { get; set; }
        public int PersonelID { get; set; }
        public DateTime Tarih { get; set; }
        public DateTime Saat { get; set; }

        public Kullanici Kullanici { get; set; }

        public Personel Personel { get; set; }




    }
}
