﻿namespace ProjeCore.Models
{
	public class Kullanici
	{

		public int KullaniciId { get; set; }
		public string KullaniciAd { get; set; }
		public string KullaniciSoyad { get; set; }
		public int KullaniciYas { get; set; }
		public string KullaniciSehir { get; set; }
		public string KullaniciTelefon { get; set; }
		public string KullaniciEmail { get; set; }
		public string KullaniciSifre { get; set; }

       public ICollection<Randev> Randev { get; set; }


    }
}
